"""
SafePay Shield - Synthetic Victim-Coercion Dataset Generator
=============================================================

Generates payer-side, payment-time records for UPI P2P/P2M payments, labelled:
    label_coerced = 1  -> true positive class: the genuine account holder is paying
                          under scammer coercion/coaching (APP-style fraud)
    label_coerced = 0  -> true negative class: genuine, self-motivated payment

Negatives are split into
    normal_negative -> everyday payments
    hard_negative   -> genuine payments that LOOK risky (large amount to a new payee,
                       on a call with family, night-time, FD broken for a wedding...)
so that a model cannot learn "big + new payee = fraud" and false positives are measurable.

Signal design is grounded in public research / industry reports (see DATA_CARD.md):
  * active call during payment (~1 in 4 APP scams involve a live call - LexisNexis)
  * coaching signs: hesitation, segmented typing, dead time, app switching (BioCatch,
    Transmit Security, Ping Identity, ITM Conf. 2026 papers)
  * remote-access / screen-share tools (LexisNexis ThreatMetrix, nhimg.org)
  * India scam mix: digital arrest, investment/trading, KYC impersonation, job/task,
    voice-clone family emergency, courier/customs, romance (I4C / MHA data)
  * new payee, amount far above the user's normal pattern (Mastercard/NuData)
  * method follows PaySim (Lopez-Rojas et al.) - parameterised agents + injected fraud

Usage:
    python generate_coercion_dataset.py --n 20000 --coerced-rate 0.12 --seed 42 \
        --out safepay_coercion_synthetic.csv
"""

import argparse
import numpy as np
import pandas as pd

UPI_P2P_LIMIT = 100_000  # Rs 1 lakh per-transaction P2P limit (typical NPCI/bank cap)

# Share of coerced cases by scam type (assumption informed by I4C/MHA reporting:
# investment/trading dominates by loss; digital arrest + impersonation are high-harm).
SCAM_MIX = {
    "investment_trading": 0.28,
    "bank_kyc_impersonation": 0.20,
    "digital_arrest": 0.15,
    "job_task": 0.15,
    "courier_customs": 0.08,
    "family_emergency_voiceclone": 0.08,
    "romance": 0.06,
}

HARD_NEG_MIX = {
    "large_new_payee_genuine": 0.25,   # hospital deposit, property token, school fees
    "family_call_while_paying": 0.25,  # child on phone reading out their account no.
    "senior_paying_family": 0.15,
    "fd_broken_for_genuine_need": 0.10,
    "night_urgent_genuine": 0.10,
    "first_time_investment_platform": 0.15,  # genuine broker/MF via merchant VPA
}


def lognorm(rng, median, sigma, n):
    return rng.lognormal(np.log(median), sigma, n)


def base_profile(rng, n, age_mean=38, age_sd=13):
    age = np.clip(rng.normal(age_mean, age_sd, n), 18, 88).round().astype(int)
    avg_txn = np.clip(lognorm(rng, 1200, 0.9, n), 50, 60_000)
    # older users hold larger balances
    bal_med = 40_000 + (age - 18) * 2_500
    balance = np.clip(rng.lognormal(np.log(bal_med), 1.0), 500, 2.5e7)
    tenure = np.clip(rng.gamma(3, 18, n), 1, 240).round().astype(int)
    return age, avg_txn, balance, tenure


def frame(n, **cols):
    return pd.DataFrame({k: (v if np.ndim(v) else np.repeat(v, n)) for k, v in cols.items()})


def behaviour(rng, n, stressed):
    """Session behaviour. stressed in [0,1] -> how strongly coaching/duress shows."""
    s = np.asarray(stressed, dtype=float)
    session = np.clip(lognorm(rng, 45, 0.6, n) * (1 + 2.5 * s * rng.uniform(0.3, 1.2, n)), 8, 3600)
    hes = rng.poisson(0.6 + 3.2 * s)
    seg = rng.binomial(1, np.clip(0.10 + 0.45 * s, 0, 1))
    switches = rng.poisson(0.5 + 2.5 * s)
    paste = rng.binomial(1, np.clip(0.25 + 0.35 * s, 0, 1))
    return session.round(), hes, seg, switches, paste


def answers(rng, n, p_know, p_unsure, p_guided_yes, purposes, p_purpose):
    u = rng.uniform(size=n)
    know = np.where(u < p_know, "yes", np.where(u < p_know + p_unsure, "unsure", "no"))
    guided = np.where(rng.uniform(size=n) < p_guided_yes, "yes", "no")
    purpose = rng.choice(purposes, n, p=p_purpose)
    return know, guided, purpose


PURPOSES = ["family", "bills_shopping", "rent_fees", "medical", "investment",
            "govt_fine_verification", "refund_cashback", "job_task_fee", "loan_repayment", "other"]


def pvec(**w):
    v = np.array([w.get(p, 0.0) for p in PURPOSES], dtype=float)
    return v / v.sum()


# ----------------------------------------------------------------------------- positives
def gen_coerced(rng, n, scam):
    if scam == "digital_arrest":
        age, avg, bal, ten = base_profile(rng, n, 58, 12)
        amt = lognorm(rng, 90_000, 0.7, n)
        voice, video = rng.binomial(1, 0.35, n), rng.binomial(1, 0.70, n)
        call_min = lognorm(rng, 140, 0.8, n)
        intl = rng.binomial(1, 0.40, n)
        screen, remote = rng.binomial(1, 0.15, n), rng.binomial(1, 0.10, n)
        stress = rng.uniform(0.6, 1.0, n)
        fd = rng.binomial(1, 0.55, n)
        multi = rng.poisson(1.8, n)
        know, guided, purpose = answers(rng, n, 0.20, 0.35, 0.20, PURPOSES,
                                        pvec(govt_fine_verification=5, family=2, other=2, investment=1))
        hours = rng.choice(np.arange(24), n, p=_hours(day=True))
    elif scam == "bank_kyc_impersonation":
        age, avg, bal, ten = base_profile(rng, n, 47, 15)
        amt = lognorm(rng, 18_000, 0.9, n)
        voice, video = rng.binomial(1, 0.85, n), rng.binomial(1, 0.03, n)
        call_min = lognorm(rng, 14, 0.6, n)
        intl = rng.binomial(1, 0.10, n)
        screen, remote = rng.binomial(1, 0.40, n), rng.binomial(1, 0.35, n)
        stress = rng.uniform(0.45, 0.95, n)
        fd = rng.binomial(1, 0.05, n)
        multi = rng.poisson(0.7, n)
        know, guided, purpose = answers(rng, n, 0.15, 0.45, 0.30, PURPOSES,
                                        pvec(refund_cashback=4, govt_fine_verification=3, other=2, bills_shopping=1))
        hours = rng.choice(np.arange(24), n, p=_hours(day=True))
    elif scam == "investment_trading":
        age, avg, bal, ten = base_profile(rng, n, 37, 10)
        amt = lognorm(rng, 35_000, 1.0, n)
        voice, video = rng.binomial(1, 0.12, n), rng.binomial(1, 0.02, n)
        call_min = lognorm(rng, 10, 0.7, n)
        intl = rng.binomial(1, 0.10, n)
        screen, remote = rng.binomial(1, 0.05, n), rng.binomial(1, 0.03, n)
        stress = rng.uniform(0.1, 0.55, n)  # greed/excitement, less visible duress
        fd = rng.binomial(1, 0.25, n)
        multi = rng.poisson(1.0, n)
        know, guided, purpose = answers(rng, n, 0.70, 0.20, 0.10, PURPOSES,
                                        pvec(investment=7, other=2, family=1))
        hours = rng.choice(np.arange(24), n, p=_hours(day=False))
    elif scam == "job_task":
        age, avg, bal, ten = base_profile(rng, n, 27, 6)
        amt = lognorm(rng, 6_000, 1.0, n)
        voice, video = rng.binomial(1, 0.08, n), rng.binomial(1, 0.01, n)
        call_min = lognorm(rng, 6, 0.6, n)
        intl = rng.binomial(1, 0.15, n)
        screen, remote = rng.binomial(1, 0.03, n), rng.binomial(1, 0.02, n)
        stress = rng.uniform(0.15, 0.6, n)
        fd = rng.binomial(1, 0.05, n)
        multi = rng.poisson(1.8, n)  # escalating "tasks"
        know, guided, purpose = answers(rng, n, 0.45, 0.35, 0.25, PURPOSES,
                                        pvec(job_task_fee=5, investment=2, other=3))
        hours = rng.choice(np.arange(24), n, p=_hours(day=False))
    elif scam == "courier_customs":
        age, avg, bal, ten = base_profile(rng, n, 45, 13)
        amt = lognorm(rng, 25_000, 0.9, n)
        voice, video = rng.binomial(1, 0.75, n), rng.binomial(1, 0.20, n)
        call_min = lognorm(rng, 40, 0.7, n)
        intl = rng.binomial(1, 0.30, n)
        screen, remote = rng.binomial(1, 0.15, n), rng.binomial(1, 0.10, n)
        stress = rng.uniform(0.5, 0.95, n)
        fd = rng.binomial(1, 0.15, n)
        multi = rng.poisson(0.8, n)
        know, guided, purpose = answers(rng, n, 0.10, 0.40, 0.25, PURPOSES,
                                        pvec(govt_fine_verification=6, other=3, bills_shopping=1))
        hours = rng.choice(np.arange(24), n, p=_hours(day=True))
    elif scam == "family_emergency_voiceclone":
        age, avg, bal, ten = base_profile(rng, n, 60, 11)
        amt = lognorm(rng, 30_000, 0.8, n)
        voice, video = rng.binomial(1, 0.85, n), rng.binomial(1, 0.02, n)
        call_min = lognorm(rng, 7, 0.5, n)
        intl = rng.binomial(1, 0.20, n)
        screen, remote = rng.binomial(1, 0.02, n), rng.binomial(1, 0.01, n)
        stress = rng.uniform(0.6, 1.0, n)
        fd = rng.binomial(1, 0.10, n)
        multi = rng.poisson(0.3, n)
        know, guided, purpose = answers(rng, n, 0.45, 0.35, 0.35, PURPOSES,
                                        pvec(family=6, medical=3, other=1))
        hours = rng.choice(np.arange(24), n, p=_hours(day=False, night_boost=2.5))
    elif scam == "romance":
        age, avg, bal, ten = base_profile(rng, n, 42, 12)
        amt = lognorm(rng, 20_000, 1.0, n)
        voice, video = rng.binomial(1, 0.15, n), rng.binomial(1, 0.05, n)
        call_min = lognorm(rng, 15, 0.7, n)
        intl = rng.binomial(1, 0.30, n)
        screen, remote = rng.binomial(1, 0.01, n), rng.binomial(1, 0.01, n)
        stress = rng.uniform(0.1, 0.5, n)
        fd = rng.binomial(1, 0.15, n)
        multi = rng.poisson(0.5, n)
        know, guided, purpose = answers(rng, n, 0.80, 0.15, 0.05, PURPOSES,
                                        pvec(family=2, medical=3, other=4, investment=1))
        hours = rng.choice(np.arange(24), n, p=_hours(day=False, night_boost=1.8))
    else:
        raise ValueError(scam)

    on_call = np.clip(voice + video, 0, 1)
    caller_in_contacts = np.where(on_call == 1, rng.binomial(1, 0.06, n), 0)
    # voice-clone scams often come from a number saved as / spoofing family
    if scam == "family_emergency_voiceclone":
        caller_in_contacts = np.where(on_call == 1, rng.binomial(1, 0.30, n), 0)

    payee_new = rng.binomial(1, 0.88, n)
    payee_contacts = np.where(payee_new == 1, rng.binomial(1, 0.03, n), rng.binomial(1, 0.20, n))
    payee_type = np.where(rng.uniform(size=n) < 0.85, "P2P", "P2M")
    # mule accounts: ~55% freshly opened, ~45% rented/compromised older accounts
    fresh = rng.uniform(size=n) < 0.55
    vpa_age = np.where(fresh, lognorm(rng, 30, 1.0, n), lognorm(rng, 450, 0.9, n))
    vpa_age = np.clip(vpa_age, 1, 4000).round()
    # most mules have no complaints yet at payment time
    reports = np.where(rng.uniform(size=n) < 0.30, rng.poisson(1.2, n) + 1, 0)

    df = _assemble(rng, n, age, avg, bal, ten, amt, hours, payee_new, payee_contacts, payee_type,
                   vpa_age, reports, voice, video, on_call, call_min, caller_in_contacts, intl,
                   screen, remote, stress, multi, fd, know, guided, purpose)
    df["label_coerced"] = 1
    df["scam_type"] = scam
    df["sample_group"] = "positive"
    df["hard_negative_reason"] = "none"
    return df


# ----------------------------------------------------------------------------- negatives
def gen_normal(rng, n):
    age, avg, bal, ten = base_profile(rng, n, 34, 12)
    amt = np.clip(avg * lognorm(rng, 1.0, 0.8, n), 10, None)
    voice = rng.binomial(1, 0.07, n); video = rng.binomial(1, 0.01, n)
    on_call = np.clip(voice + video, 0, 1)
    call_min = lognorm(rng, 4, 0.8, n)
    caller_in_contacts = np.where(on_call == 1, rng.binomial(1, 0.85, n), 0)
    intl = rng.binomial(1, 0.01, n)
    screen, remote = rng.binomial(1, 0.005, n), rng.binomial(1, 0.01, n)
    stress = rng.beta(1.2, 7, n)
    multi = rng.poisson(0.3, n)
    fd = rng.binomial(1, 0.01, n)
    payee_new = rng.binomial(1, 0.18, n)
    payee_contacts = np.where(payee_new == 1, rng.binomial(1, 0.35, n), rng.binomial(1, 0.55, n))
    payee_type = np.where(rng.uniform(size=n) < 0.45, "P2P", "P2M")
    vpa_age = np.where(payee_new == 1, lognorm(rng, 200, 1.4, n), lognorm(rng, 800, 0.9, n))
    vpa_age = np.clip(vpa_age, 1, 4000).round()
    reports = np.where(rng.uniform(size=n) < 0.015, rng.poisson(0.5, n) + 1, 0)  # false/old complaints
    know, guided, purpose = answers(rng, n, 0.93, 0.05, 0.03, PURPOSES,
                                    pvec(bills_shopping=6, family=2, rent_fees=1, loan_repayment=0.5,
                                         medical=0.3, investment=0.3, other=0.5))
    hours = rng.choice(np.arange(24), n, p=_hours(day=True))
    df = _assemble(rng, n, age, avg, bal, ten, amt, hours, payee_new, payee_contacts, payee_type,
                   vpa_age, reports, voice, video, on_call, call_min, caller_in_contacts, intl,
                   screen, remote, stress, multi, fd, know, guided, purpose)
    df["label_coerced"] = 0
    df["scam_type"] = "none"
    df["sample_group"] = "normal_negative"
    df["hard_negative_reason"] = "none"
    return df


def gen_hard(rng, n, reason):
    age, avg, bal, ten = base_profile(rng, n, 40, 14)
    amt = np.clip(avg * lognorm(rng, 1.5, 0.8, n), 10, None)
    voice = rng.binomial(1, 0.08, n); video = rng.binomial(1, 0.01, n)
    call_min = lognorm(rng, 5, 0.8, n)
    caller_in_contacts_p = 0.85
    intl = rng.binomial(1, 0.02, n)
    screen, remote = rng.binomial(1, 0.01, n), rng.binomial(1, 0.02, n)
    stress = rng.beta(1.5, 5, n)
    multi = rng.poisson(0.7, n)
    fd = rng.binomial(1, 0.02, n)
    payee_new = rng.binomial(1, 0.30, n)
    payee_type = np.where(rng.uniform(size=n) < 0.5, "P2P", "P2M")
    vpa_age = np.clip(lognorm(rng, 500, 1.0, n), 1, 4000).round()
    p_know, p_uns, p_guid = 0.85, 0.10, 0.08
    purpose_p = pvec(bills_shopping=2, family=3, rent_fees=2, medical=1, investment=1, other=1)
    hours = rng.choice(np.arange(24), n, p=_hours(day=True))

    if reason == "large_new_payee_genuine":
        amt = lognorm(rng, 45_000, 0.8, n); payee_new = np.ones(n, int)
        stress = rng.beta(2, 4, n)
        purpose_p = pvec(medical=3, rent_fees=4, other=2, bills_shopping=1)
        vpa_age = np.clip(lognorm(rng, 250, 1.2, n), 1, 4000).round()
    elif reason == "family_call_while_paying":
        voice = rng.binomial(1, 0.85, n); video = rng.binomial(1, 0.15, n)
        call_min = lognorm(rng, 8, 0.7, n); caller_in_contacts_p = 0.93
        payee_new = rng.binomial(1, 0.55, n); stress = rng.beta(2, 4, n)
        p_guid = 0.45  # honestly says "yes, my son is telling me"
        purpose_p = pvec(family=6, medical=1, rent_fees=1, bills_shopping=1)
    elif reason == "senior_paying_family":
        age = np.clip(rng.normal(66, 7, n), 55, 88).round().astype(int)
        amt = lognorm(rng, 20_000, 0.8, n); payee_new = rng.binomial(1, 0.35, n)
        stress = rng.beta(2.5, 4, n)  # slower, more hesitant UI use - NOT coercion
        voice = rng.binomial(1, 0.30, n); caller_in_contacts_p = 0.95
        purpose_p = pvec(family=7, medical=2, other=1)
    elif reason == "fd_broken_for_genuine_need":
        fd = np.ones(n, int); amt = lognorm(rng, 60_000, 0.7, n)
        payee_new = rng.binomial(1, 0.55, n); multi = rng.poisson(1.2, n)
        purpose_p = pvec(medical=3, rent_fees=3, family=3, other=1)
    elif reason == "night_urgent_genuine":
        hours = rng.choice([22, 23, 0, 1, 2, 3], n)
        amt = lognorm(rng, 8_000, 0.9, n); stress = rng.beta(2.5, 3.5, n)
        purpose_p = pvec(medical=4, family=4, bills_shopping=2)
    elif reason == "first_time_investment_platform":
        age = np.clip(rng.normal(32, 8, n), 18, 70).round().astype(int)
        amt = lognorm(rng, 15_000, 1.0, n); payee_new = np.ones(n, int)
        payee_type = np.where(rng.uniform(size=n) < 0.9, "P2M", "P2P")
        vpa_age = np.clip(lognorm(rng, 1500, 0.6, n), 30, 4000).round()
        purpose_p = pvec(investment=9, other=1)
    else:
        raise ValueError(reason)

    on_call = np.clip(voice + video, 0, 1)
    caller_in_contacts = np.where(on_call == 1, rng.binomial(1, caller_in_contacts_p, n), 0)
    payee_contacts = np.where(payee_new == 1, rng.binomial(1, 0.30, n), rng.binomial(1, 0.60, n))
    vpa_age = np.where((payee_new == 1) & (rng.uniform(size=n) < 0.4), lognorm(rng, 40, 1.0, n), vpa_age)
    vpa_age = np.clip(vpa_age, 1, 4000).round()
    reports = np.where(rng.uniform(size=n) < 0.03, rng.poisson(0.6, n) + 1, 0)
    know, guided, purpose = answers(rng, n, p_know, p_uns, p_guid, PURPOSES, purpose_p)
    df = _assemble(rng, n, age, avg, bal, ten, amt, hours, payee_new, payee_contacts, payee_type,
                   vpa_age, reports, voice, video, on_call, call_min, caller_in_contacts, intl,
                   screen, remote, stress, multi, fd, know, guided, purpose)
    df["label_coerced"] = 0
    df["scam_type"] = "none"
    df["sample_group"] = "hard_negative"
    df["hard_negative_reason"] = reason
    return df


# ----------------------------------------------------------------------------- helpers
def _hours(day=True, night_boost=1.0):
    w = np.array([1, .6, .4, .3, .3, .5, 1.5, 3, 5, 6, 6.5, 6.5, 6.5, 6, 6, 6, 6, 6.5, 7, 7, 6.5, 5, 3.5, 2], float)
    if not day:
        w = w * np.array([2.5 if h in (22, 23, 0, 1, 2, 3) else 1 for h in range(24)])
    if night_boost != 1.0:
        w = w * np.array([night_boost if h in (21, 22, 23, 0, 1, 2) else 1 for h in range(24)])
    return w / w.sum()


def _assemble(rng, n, age, avg, bal, ten, amt, hours, payee_new, payee_contacts, payee_type,
              vpa_age, reports, voice, video, on_call, call_min, caller_in_contacts, intl,
              screen, remote, stress, multi, fd, know, guided, purpose):
    amt = np.clip(np.round(amt, -1), 10, UPI_P2P_LIMIT)
    bal = np.maximum(bal, amt * rng.uniform(1.05, 3.0, n))  # payment must be fundable
    session, hes, seg, switches, paste = behaviour(rng, n, stress)
    call_min = np.where(on_call == 1, np.round(np.clip(call_min, 0.5, 900), 1), 0.0)
    intl = np.where(on_call == 1, intl, 0)
    prior_24h = multi  # earlier payments to new payees in last 24h
    sent_24h = np.round(amt * prior_24h * rng.uniform(0.6, 1.2, n), -1)
    return pd.DataFrame({
        "hour_of_day": hours,
        "user_age": age,
        "account_tenure_months": ten,
        "avg_txn_amount_90d": np.round(avg, 0),
        "balance_before_txn": np.round(bal, 0),
        "amount_inr": amt,
        "amount_to_avg_ratio": np.round(amt / avg, 2),
        "amount_pct_of_balance": np.round(100 * amt / bal, 2),
        "payee_is_new": payee_new,
        "payee_in_contacts": payee_contacts,
        "payee_type": payee_type,
        "payee_vpa_age_days": vpa_age.astype(int),
        "payee_prior_complaints": reports,
        "on_voice_call": voice,
        "on_video_call": video,
        "call_duration_min": call_min,
        "caller_in_contacts": caller_in_contacts,
        "caller_is_international": intl,
        "screen_share_active": screen,
        "remote_access_app_installed_7d": remote,
        "session_duration_sec": session.astype(int),
        "hesitation_events": hes,
        "segmented_typing": seg,
        "app_switches": switches,
        "vpa_pasted": paste,
        "new_payee_txns_24h": prior_24h,
        "amount_sent_new_payees_24h": sent_24h,
        "fd_or_loan_liquidated_7d": fd,
        "ans_know_payee": know,
        "ans_someone_guiding": guided,
        "ans_purpose": purpose,
    })


def split(total, mix):
    keys = list(mix); p = np.array([mix[k] for k in keys]); p = p / p.sum()
    counts = np.floor(p * total).astype(int); counts[0] += total - counts.sum()
    return dict(zip(keys, counts))


def generate(n=20_000, coerced_rate=0.12, hard_share=0.25, label_noise=0.01, seed=42):
    rng = np.random.default_rng(seed)
    n_pos = int(round(n * coerced_rate)); n_neg = n - n_pos
    n_hard = int(round(n_neg * hard_share)); n_norm = n_neg - n_hard
    parts = [gen_coerced(rng, k, s) for s, k in split(n_pos, SCAM_MIX).items() if k]
    parts += [gen_hard(rng, k, r) for r, k in split(n_hard, HARD_NEG_MIX).items() if k]
    parts.append(gen_normal(rng, n_norm))
    df = pd.concat(parts, ignore_index=True).sample(frac=1, random_state=seed).reset_index(drop=True)

    # label noise: imperfect ground truth (unreported scams, disputed claims)
    df["label_noisy"] = 0
    flip = rng.uniform(size=len(df)) < label_noise
    df.loc[flip, "label_coerced"] = 1 - df.loc[flip, "label_coerced"]
    df.loc[flip, "label_noisy"] = 1

    df.insert(0, "txn_id", [f"SPS{seed:02d}{i:07d}" for i in range(len(df))])
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=20_000)
    ap.add_argument("--coerced-rate", type=float, default=0.12)
    ap.add_argument("--hard-share", type=float, default=0.25)
    ap.add_argument("--label-noise", type=float, default=0.01)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="safepay_coercion_synthetic.csv")
    a = ap.parse_args()
    d = generate(a.n, a.coerced_rate, a.hard_share, a.label_noise, a.seed)
    d.to_csv(a.out, index=False)
    print(f"wrote {len(d)} rows -> {a.out}")
    print(d["sample_group"].value_counts().to_string())
