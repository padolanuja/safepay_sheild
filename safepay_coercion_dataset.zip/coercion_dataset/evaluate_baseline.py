"""Baseline check: rule vs. ML on the synthetic coercion dataset. Prints TP/TN/FP/FN."""
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, roc_auc_score, precision_score, recall_score, f1_score

path = sys.argv[1] if len(sys.argv) > 1 else "safepay_coercion_synthetic.csv"
df = pd.read_csv(path)
y = df["label_coerced"]
drop = ["txn_id", "label_coerced", "scam_type", "sample_group", "hard_negative_reason", "label_noisy"]
X = pd.get_dummies(df.drop(columns=drop), columns=["payee_type", "ans_know_payee", "ans_someone_guiding", "ans_purpose"], dtype=int)
Xtr, Xte, ytr, yte, gtr, gte = train_test_split(X, y, df[["sample_group", "scam_type", "hard_negative_reason"]],
                                                test_size=0.3, stratify=y, random_state=7)


def report(name, pred, score=None):
    tn, fp, fn, tp = confusion_matrix(yte, pred).ravel()
    line = f"{name:<22} TP={tp:5d} TN={tn:5d} FP={fp:5d} FN={fn:5d} | P={precision_score(yte, pred):.3f} R={recall_score(yte, pred):.3f} F1={f1_score(yte, pred):.3f}"
    if score is not None:
        line += f" AUC={roc_auc_score(yte, score):.3f}"
    hard = gte["sample_group"] == "hard_negative"
    line += f" | FP-rate on hard negatives={pred[hard.values].mean():.3f}, on normal={pred[(gte['sample_group']=='normal_negative').values].mean():.3f}"
    print(line)
    return pred


# Rule baseline: what a simple "new payee + big amount" rule would do
rule = ((Xte["payee_is_new"] == 1) & (Xte["amount_to_avg_ratio"] > 5)).astype(int).values
report("Rule: new+5x amount", rule)
rule2 = ((Xte["payee_is_new"] == 1) & ((Xte["on_voice_call"] + Xte["on_video_call"]) > 0) & (Xte["caller_in_contacts"] == 0)).astype(int).values
report("Rule: new+unknown call", rule2)

lr = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, class_weight="balanced")).fit(Xtr, ytr)
s = lr.predict_proba(Xte)[:, 1]; report("LogisticRegression", (s > 0.5).astype(int), s)

rf = RandomForestClassifier(n_estimators=300, min_samples_leaf=3, class_weight="balanced", n_jobs=-1, random_state=7).fit(Xtr, ytr)
s = rf.predict_proba(Xte)[:, 1]; p = (s > 0.5).astype(int); report("RandomForest", p, s)

print("\nRandomForest recall by scam type:")
pos = (yte == 1).values
for t, g in pd.Series(p[pos], index=gte["scam_type"].values[pos]).groupby(level=0):
    print(f"  {t:<30} {g.mean():.3f}  (n={len(g)})")
print("\nRandomForest false-positive rate by hard-negative reason:")
neg = (gte["sample_group"] == "hard_negative").values
for t, g in pd.Series(p[neg], index=gte["hard_negative_reason"].values[neg]).groupby(level=0):
    print(f"  {t:<30} {g.mean():.3f}  (n={len(g)})")
print("\nTop 12 features:")
imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False).head(12)
print(imp.round(3).to_string())
